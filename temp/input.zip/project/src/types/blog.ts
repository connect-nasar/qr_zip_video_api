export interface BlogPost {
  id: string;
  title: string;
  content: string;
  excerpt: string;
  author: string;
  category: string;
  tags: string[];
  publishedAt: Date;
  updatedAt: Date;
  readingTime: number;
  featured: boolean;
  status: 'draft' | 'published';
  slug: string;
  // SEO fields
  metaTitle?: string;
  metaDescription?: string;
  metaKeywords?: string;
  ogTitle?: string;
  ogDescription?: string;
  ogImage?: string;
  canonicalUrl?: string;
  focusKeyword?: string;
  seoScore?: number;
}

export interface BlogCategory {
  id: string;
  name: string;
  slug: string;
  description: string;
  postCount: number;
  // SEO fields
  metaTitle?: string;
  metaDescription?: string;
}

export interface BlogFilters {
  category: string;
  tags: string[];
  searchQuery: string;
  status: 'all' | 'published' | 'draft';
}

export interface SiteSettings {
  siteName: string;
  siteDescription: string;
  siteUrl: string;
  defaultMetaTitle: string;
  defaultMetaDescription: string;
  googleAnalyticsId?: string;
  googleSearchConsoleId?: string;
  favicon?: string;
  logo?: string;
  socialMedia: {
    twitter?: string;
    facebook?: string;
    linkedin?: string;
    instagram?: string;
  };
}

export interface Comment {
  id: string;
  postId: string;
  author: string;
  email: string;
  content: string;
  createdAt: Date;
  approved: boolean;
  parentId?: string; // For replies
}

export interface AdminUser {
  username: string;
  password: string;
  role: 'admin' | 'editor';
}