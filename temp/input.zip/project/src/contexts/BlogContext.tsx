import React, { createContext, useContext, useState, useEffect, ReactNode } from 'react';
import { BlogPost, BlogCategory, BlogFilters, SiteSettings, Comment, AdminUser } from '../types/blog';
import { v4 as uuidv4 } from 'uuid';
import { slugify } from '../utils/blog';

interface BlogContextType {
  posts: BlogPost[];
  categories: BlogCategory[];
  filters: BlogFilters;
  siteSettings: SiteSettings;
  comments: Comment[];
  adminUser: AdminUser | null;
  isAuthenticated: boolean;
  addPost: (post: Omit<BlogPost, 'id' | 'publishedAt' | 'updatedAt' | 'slug'>) => void;
  updatePost: (id: string, updates: Partial<BlogPost>) => void;
  deletePost: (id: string) => void;
  getPost: (id: string) => BlogPost | undefined;
  getPostBySlug: (slug: string) => BlogPost | undefined;
  setFilters: (filters: Partial<BlogFilters>) => void;
  getFilteredPosts: () => BlogPost[];
  addCategory: (category: Omit<BlogCategory, 'id' | 'postCount'>) => void;
  updateSiteSettings: (settings: Partial<SiteSettings>) => void;
  getPublishedPosts: () => BlogPost[];
  addComment: (comment: Omit<Comment, 'id' | 'createdAt' | 'approved'>) => void;
  getPostComments: (postId: string) => Comment[];
  approveComment: (commentId: string) => void;
  deleteComment: (commentId: string) => void;
  login: (username: string, password: string) => boolean;
  logout: () => void;
}

const BlogContext = createContext<BlogContextType | undefined>(undefined);

export const useBlog = () => {
  const context = useContext(BlogContext);
  if (!context) {
    throw new Error('useBlog must be used within a BlogProvider');
  }
  return context;
};

interface BlogProviderProps {
  children: ReactNode;
}

const initialSiteSettings: SiteSettings = {
  siteName: "How To?",
  siteDescription: "Your ultimate guide to learning anything and everything. Step-by-step tutorials, tips, and expert advice.",
  siteUrl: "https://howto.example.com",
  defaultMetaTitle: "How To? - Learn Anything Step by Step",
  defaultMetaDescription: "Discover comprehensive tutorials and guides on various topics. Learn new skills with our easy-to-follow step-by-step instructions.",
  socialMedia: {
    twitter: "@howto",
    facebook: "howtoguides",
    linkedin: "company/howto"
  }
};

const defaultAdmin: AdminUser = {
  username: "admin",
  password: "admin123",
  role: "admin"
};

const initialPosts: BlogPost[] = [
  {
    id: uuidv4(),
    title: "How to Build a Modern Website in 2024",
    slug: "how-to-build-modern-website-2024",
    content: `# How to Build a Modern Website in 2024

Building a modern website requires understanding current web technologies, design principles, and user experience best practices. This comprehensive guide will walk you through the entire process.

## Planning Your Website

Before writing any code, proper planning is essential:

### Define Your Goals
- **Purpose**: What is your website's main objective?
- **Target Audience**: Who are you building this for?
- **Content Strategy**: What content will you provide?
- **Success Metrics**: How will you measure success?

### Choose Your Technology Stack
Modern websites typically use:
- **Frontend**: React, Vue.js, or vanilla JavaScript
- **Styling**: Tailwind CSS, CSS Modules, or Styled Components
- **Backend**: Node.js, Python, or serverless functions
- **Database**: PostgreSQL, MongoDB, or cloud databases
- **Hosting**: Vercel, Netlify, or AWS

## Design and User Experience

### Mobile-First Approach
Start designing for mobile devices first, then scale up:
- Use responsive design principles
- Optimize touch interactions
- Consider thumb-friendly navigation
- Test on real devices

### Performance Optimization
- **Image Optimization**: Use WebP format and lazy loading
- **Code Splitting**: Load only necessary JavaScript
- **Caching**: Implement proper caching strategies
- **CDN**: Use content delivery networks

### Accessibility
Make your website accessible to everyone:
- Use semantic HTML elements
- Provide alt text for images
- Ensure proper color contrast
- Support keyboard navigation
- Test with screen readers

## Development Best Practices

### Version Control
- Use Git for version control
- Create meaningful commit messages
- Use branching strategies
- Set up automated deployments

### Testing
- Write unit tests for critical functions
- Implement integration tests
- Perform cross-browser testing
- Test on multiple devices

### SEO Optimization
- Use proper heading structure (H1, H2, H3)
- Optimize meta tags and descriptions
- Create XML sitemaps
- Implement structured data
- Ensure fast loading times

## Launch and Maintenance

### Pre-Launch Checklist
- Test all functionality
- Verify responsive design
- Check loading speeds
- Validate HTML and CSS
- Test contact forms
- Set up analytics

### Post-Launch
- Monitor website performance
- Regular security updates
- Content updates and maintenance
- Backup strategies
- User feedback collection

## Conclusion

Building a modern website is an iterative process that requires attention to detail, user-centered design, and ongoing maintenance. By following these guidelines and staying updated with web development trends, you can create websites that provide excellent user experiences and achieve your business goals.`,
    excerpt: "A comprehensive guide to building modern websites in 2024, covering planning, design, development, and launch strategies.",
    author: "Alex Thompson",
    category: "Web Development",
    tags: ["Web Development", "Modern Design", "2024", "Tutorial", "Best Practices"],
    publishedAt: new Date('2024-01-15'),
    updatedAt: new Date('2024-01-15'),
    readingTime: 12,
    featured: true,
    status: 'published',
    metaTitle: "How to Build a Modern Website in 2024 - Complete Guide",
    metaDescription: "Learn how to build a modern website in 2024 with this comprehensive guide covering planning, design, development, and launch strategies.",
    metaKeywords: "modern website, web development 2024, website building guide, responsive design, SEO optimization",
    focusKeyword: "modern website 2024",
    seoScore: 85
  },
  {
    id: uuidv4(),
    title: "How to Start a Successful Blog",
    slug: "how-to-start-successful-blog",
    content: `# How to Start a Successful Blog

Starting a blog can be one of the most rewarding ways to share your knowledge, build an audience, and even generate income. This guide will walk you through everything you need to know.

## Finding Your Niche

### Identify Your Passion
Choose a topic you're genuinely passionate about:
- What subjects do you naturally gravitate toward?
- What problems can you help solve?
- What unique perspective can you offer?

### Research Your Market
- Analyze existing blogs in your niche
- Identify content gaps you can fill
- Understand your target audience
- Study successful bloggers' strategies

## Setting Up Your Blog

### Choose a Platform
Popular blogging platforms include:
- **WordPress.org**: Most flexible and customizable
- **Ghost**: Clean, focused on writing
- **Medium**: Built-in audience but limited customization
- **Substack**: Great for newsletters and subscriptions

### Select a Domain Name
Your domain should be:
- Easy to remember and spell
- Related to your niche or brand
- Short and professional
- Available across social media platforms

## Creating Quality Content

### Content Planning
- Develop a content calendar
- Plan posts around keywords
- Mix different content types
- Maintain consistent publishing schedule

### Writing Tips
- **Headlines**: Create compelling, clickable titles
- **Structure**: Use headings, bullet points, and short paragraphs
- **Value**: Always provide actionable insights
- **Voice**: Develop your unique writing style

### SEO Optimization
- Research keywords before writing
- Optimize title tags and meta descriptions
- Use internal and external links
- Include relevant images with alt text
- Write for humans, not just search engines

## Building an Audience

### Social Media Strategy
- Choose platforms where your audience hangs out
- Share valuable content consistently
- Engage with your community
- Use relevant hashtags
- Cross-promote your blog posts

### Email Marketing
- Start building an email list from day one
- Offer valuable lead magnets
- Send regular newsletters
- Segment your audience
- Personalize your communications

## Monetization Strategies

### Advertising
- Google AdSense for beginners
- Direct ad sales for established blogs
- Sponsored content and reviews
- Newsletter sponsorships

### Affiliate Marketing
- Promote products you genuinely use
- Disclose affiliate relationships
- Focus on value, not just sales
- Track performance and optimize

## Conclusion

Starting a successful blog takes time, effort, and patience. Focus on providing value to your readers, stay consistent with your content creation, and don't be afraid to experiment with different strategies.`,
    excerpt: "Learn how to start and grow a successful blog with this comprehensive guide covering niche selection, content creation, audience building, and monetization.",
    author: "Sarah Mitchell",
    category: "Blogging",
    tags: ["Blogging", "Content Creation", "Online Business", "Digital Marketing", "SEO"],
    publishedAt: new Date('2024-01-10'),
    updatedAt: new Date('2024-01-10'),
    readingTime: 15,
    featured: true,
    status: 'published',
    metaTitle: "How to Start a Successful Blog - Complete Beginner's Guide",
    metaDescription: "Start your blogging journey with this comprehensive guide. Learn niche selection, content creation, audience building, and monetization strategies.",
    metaKeywords: "start a blog, blogging guide, successful blog, blog monetization, content creation",
    focusKeyword: "start a successful blog",
    seoScore: 90
  },
  {
    id: uuidv4(),
    title: "How to Learn Programming from Scratch",
    slug: "how-to-learn-programming-from-scratch",
    content: `# How to Learn Programming from Scratch

Learning to program can seem overwhelming, but with the right approach and mindset, anyone can master this valuable skill. This guide will provide you with a clear roadmap to start your programming journey.

## Understanding Programming Fundamentals

### What is Programming?
Programming is the process of creating instructions for computers to follow. These instructions, written in programming languages, tell the computer how to perform specific tasks.

### Core Concepts to Master
- **Variables**: Storing and manipulating data
- **Functions**: Reusable blocks of code
- **Loops**: Repeating actions efficiently
- **Conditionals**: Making decisions in code
- **Data Structures**: Organizing information
- **Algorithms**: Step-by-step problem-solving methods

## Choosing Your First Programming Language

### Beginner-Friendly Options

#### Python
- **Pros**: Easy syntax, versatile, large community
- **Best for**: Data science, web development, automation
- **Learning curve**: Gentle

#### JavaScript
- **Pros**: Runs in browsers, high demand, immediate visual results
- **Best for**: Web development, mobile apps
- **Learning curve**: Moderate

#### Java
- **Pros**: Widely used, strong job market, structured
- **Best for**: Enterprise applications, Android development
- **Learning curve**: Steeper but thorough

## Setting Up Your Learning Environment

### Essential Tools
- **Code Editor**: VS Code, Atom, or Sublime Text
- **Version Control**: Git and GitHub
- **Terminal/Command Line**: Basic navigation skills
- **Browser Developer Tools**: For web development

### Online Learning Platforms
- **Free Resources**: freeCodeCamp, Codecademy, Khan Academy
- **Paid Courses**: Udemy, Coursera, Pluralsight
- **Interactive Platforms**: LeetCode, HackerRank, Codewars
- **Documentation**: Official language documentation

## Creating a Learning Plan

### Phase 1: Foundations (Weeks 1-4)
- Learn basic syntax and concepts
- Write simple programs
- Understand variables and data types
- Practice with basic input/output

### Phase 2: Core Programming (Weeks 5-12)
- Master functions and scope
- Learn about loops and conditionals
- Understand arrays and objects
- Practice problem-solving

### Phase 3: Intermediate Concepts (Weeks 13-24)
- Object-oriented programming
- Error handling and debugging
- Working with APIs
- Database basics

## Effective Learning Strategies

### Active Learning Techniques
- **Code Along**: Follow tutorials while typing code
- **Project-Based Learning**: Build real applications
- **Teach Others**: Explain concepts to solidify understanding
- **Code Reviews**: Get feedback from experienced developers

### Practice Methods
- **Daily Coding**: Consistency is key
- **Coding Challenges**: Solve algorithmic problems
- **Personal Projects**: Build things you're interested in
- **Pair Programming**: Code with others

## Building Your First Projects

### Beginner Projects
- **Calculator**: Practice basic operations and user input
- **To-Do List**: Learn about data manipulation
- **Weather App**: Work with APIs and external data
- **Personal Website**: Combine HTML, CSS, and JavaScript

## Conclusion

Learning programming is a journey that requires patience, practice, and persistence. Start with the fundamentals, choose one language to focus on initially, and build projects that interest you. Remember that every expert was once a beginner.`,
    excerpt: "A complete beginner's guide to learning programming from scratch, covering language selection, learning strategies, and practical project ideas.",
    author: "David Chen",
    category: "Programming",
    tags: ["Programming", "Beginner Guide", "Learning", "Career Development", "Coding"],
    publishedAt: new Date('2024-01-05'),
    updatedAt: new Date('2024-01-05'),
    readingTime: 18,
    featured: false,
    status: 'published',
    metaTitle: "How to Learn Programming from Scratch - Complete Beginner's Guide",
    metaDescription: "Start your programming journey with this comprehensive guide. Learn language selection, effective strategies, and build your first projects.",
    metaKeywords: "learn programming, programming for beginners, coding tutorial, programming languages, software development",
    focusKeyword: "learn programming from scratch",
    seoScore: 88
  }
];

const initialCategories: BlogCategory[] = [
  { 
    id: uuidv4(), 
    name: "Web Development", 
    slug: "web-development", 
    description: "Learn modern web development techniques and frameworks", 
    postCount: 1,
    metaTitle: "Web Development Tutorials - How To?",
    metaDescription: "Master web development with our comprehensive tutorials covering HTML, CSS, JavaScript, React, and more."
  },
  { 
    id: uuidv4(), 
    name: "Blogging", 
    slug: "blogging", 
    description: "Tips and strategies for successful blogging", 
    postCount: 1,
    metaTitle: "Blogging Tips and Strategies - How To?",
    metaDescription: "Learn how to start, grow, and monetize your blog with our expert blogging guides and tutorials."
  },
  { 
    id: uuidv4(), 
    name: "Programming", 
    slug: "programming", 
    description: "Programming tutorials and best practices", 
    postCount: 1,
    metaTitle: "Programming Tutorials - How To?",
    metaDescription: "Learn programming from scratch with our step-by-step tutorials covering various languages and concepts."
  },
  { 
    id: uuidv4(), 
    name: "Digital Marketing", 
    slug: "digital-marketing", 
    description: "Digital marketing strategies and techniques", 
    postCount: 0,
    metaTitle: "Digital Marketing Guides - How To?",
    metaDescription: "Master digital marketing with our comprehensive guides covering SEO, social media, email marketing, and more."
  },
  { 
    id: uuidv4(), 
    name: "Design", 
    slug: "design", 
    description: "Design principles and creative tutorials", 
    postCount: 0,
    metaTitle: "Design Tutorials - How To?",
    metaDescription: "Learn design principles, UI/UX best practices, and creative techniques with our design tutorials."
  }
];

export const BlogProvider: React.FC<BlogProviderProps> = ({ children }) => {
  const [posts, setPosts] = useState<BlogPost[]>([]);
  const [categories, setCategories] = useState<BlogCategory[]>([]);
  const [comments, setComments] = useState<Comment[]>([]);
  const [siteSettings, setSiteSettings] = useState<SiteSettings>(initialSiteSettings);
  const [adminUser, setAdminUser] = useState<AdminUser | null>(null);
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const [filters, setFilters] = useState<BlogFilters>({
    category: '',
    tags: [],
    searchQuery: '',
    status: 'all'
  });

  // Load data from localStorage on mount
  useEffect(() => {
    const savedPosts = localStorage.getItem('blogPosts');
    const savedCategories = localStorage.getItem('blogCategories');
    const savedComments = localStorage.getItem('blogComments');
    const savedSettings = localStorage.getItem('siteSettings');
    const savedAuth = localStorage.getItem('adminAuth');
    
    if (savedPosts) {
      const parsedPosts = JSON.parse(savedPosts).map((post: any) => ({
        ...post,
        publishedAt: new Date(post.publishedAt),
        updatedAt: new Date(post.updatedAt)
      }));
      setPosts(parsedPosts);
    } else {
      setPosts(initialPosts);
    }
    
    if (savedCategories) {
      setCategories(JSON.parse(savedCategories));
    } else {
      setCategories(initialCategories);
    }

    if (savedComments) {
      const parsedComments = JSON.parse(savedComments).map((comment: any) => ({
        ...comment,
        createdAt: new Date(comment.createdAt)
      }));
      setComments(parsedComments);
    }

    if (savedSettings) {
      setSiteSettings(JSON.parse(savedSettings));
    }

    if (savedAuth) {
      setIsAuthenticated(true);
      setAdminUser(defaultAdmin);
    }
  }, []);

  // Save data to localStorage
  useEffect(() => {
    localStorage.setItem('blogPosts', JSON.stringify(posts));
  }, [posts]);

  useEffect(() => {
    localStorage.setItem('blogCategories', JSON.stringify(categories));
  }, [categories]);

  useEffect(() => {
    localStorage.setItem('blogComments', JSON.stringify(comments));
  }, [comments]);

  useEffect(() => {
    localStorage.setItem('siteSettings', JSON.stringify(siteSettings));
  }, [siteSettings]);

  const addPost = (postData: Omit<BlogPost, 'id' | 'publishedAt' | 'updatedAt' | 'slug'>) => {
    const slug = slugify(postData.title);
    const newPost: BlogPost = {
      ...postData,
      id: uuidv4(),
      slug,
      publishedAt: new Date(),
      updatedAt: new Date()
    };
    setPosts(prev => [newPost, ...prev]);
    
    if (postData.category) {
      updateCategoryPostCount(postData.category, 1);
    }
  };

  const updatePost = (id: string, updates: Partial<BlogPost>) => {
    setPosts(prev => prev.map(post => 
      post.id === id 
        ? { 
            ...post, 
            ...updates, 
            slug: updates.title ? slugify(updates.title) : post.slug,
            updatedAt: new Date() 
          }
        : post
    ));
  };

  const deletePost = (id: string) => {
    const post = posts.find(p => p.id === id);
    if (post) {
      setPosts(prev => prev.filter(p => p.id !== id));
      updateCategoryPostCount(post.category, -1);
    }
  };

  const getPost = (id: string) => {
    return posts.find(post => post.id === id);
  };

  const getPostBySlug = (slug: string) => {
    return posts.find(post => post.slug === slug);
  };

  const updateFilters = (newFilters: Partial<BlogFilters>) => {
    setFilters(prev => ({ ...prev, ...newFilters }));
  };

  const getFilteredPosts = () => {
    return posts.filter(post => {
      const matchesCategory = !filters.category || post.category === filters.category;
      const matchesTags = filters.tags.length === 0 || 
        filters.tags.some(tag => post.tags.includes(tag));
      const matchesSearch = !filters.searchQuery || 
        post.title.toLowerCase().includes(filters.searchQuery.toLowerCase()) ||
        post.content.toLowerCase().includes(filters.searchQuery.toLowerCase()) ||
        post.excerpt.toLowerCase().includes(filters.searchQuery.toLowerCase());
      const matchesStatus = filters.status === 'all' || post.status === filters.status;
      
      return matchesCategory && matchesTags && matchesSearch && matchesStatus;
    });
  };

  const getPublishedPosts = () => {
    return posts.filter(post => post.status === 'published').sort((a, b) => 
      new Date(b.publishedAt).getTime() - new Date(a.publishedAt).getTime()
    );
  };

  const addCategory = (categoryData: Omit<BlogCategory, 'id' | 'postCount'>) => {
    const newCategory: BlogCategory = {
      ...categoryData,
      id: uuidv4(),
      postCount: 0
    };
    setCategories(prev => [...prev, newCategory]);
  };

  const updateCategoryPostCount = (categoryName: string, change: number) => {
    setCategories(prev => prev.map(cat => 
      cat.name === categoryName 
        ? { ...cat, postCount: Math.max(0, cat.postCount + change) }
        : cat
    ));
  };

  const updateSiteSettings = (settings: Partial<SiteSettings>) => {
    setSiteSettings(prev => ({ ...prev, ...settings }));
  };

  const addComment = (commentData: Omit<Comment, 'id' | 'createdAt' | 'approved'>) => {
    const newComment: Comment = {
      ...commentData,
      id: uuidv4(),
      createdAt: new Date(),
      approved: false // Comments need approval by default
    };
    setComments(prev => [...prev, newComment]);
  };

  const getPostComments = (postId: string) => {
    return comments
      .filter(comment => comment.postId === postId && comment.approved)
      .sort((a, b) => new Date(a.createdAt).getTime() - new Date(b.createdAt).getTime());
  };

  const approveComment = (commentId: string) => {
    setComments(prev => prev.map(comment =>
      comment.id === commentId ? { ...comment, approved: true } : comment
    ));
  };

  const deleteComment = (commentId: string) => {
    setComments(prev => prev.filter(comment => comment.id !== commentId));
  };

  const login = (username: string, password: string) => {
    if (username === defaultAdmin.username && password === defaultAdmin.password) {
      setIsAuthenticated(true);
      setAdminUser(defaultAdmin);
      localStorage.setItem('adminAuth', 'true');
      return true;
    }
    return false;
  };

  const logout = () => {
    setIsAuthenticated(false);
    setAdminUser(null);
    localStorage.removeItem('adminAuth');
  };

  return (
    <BlogContext.Provider value={{
      posts,
      categories,
      filters,
      siteSettings,
      comments,
      adminUser,
      isAuthenticated,
      addPost,
      updatePost,
      deletePost,
      getPost,
      getPostBySlug,
      setFilters: updateFilters,
      getFilteredPosts,
      addCategory,
      updateSiteSettings,
      getPublishedPosts,
      addComment,
      getPostComments,
      approveComment,
      deleteComment,
      login,
      logout
    }}>
      {children}
    </BlogContext.Provider>
  );
};