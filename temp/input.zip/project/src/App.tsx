import React from 'react';
import { BlogProvider } from './contexts/BlogContext';
import Router from './components/Router/Router';

function App() {
  return (
    <BlogProvider>
      <Router />
    </BlogProvider>
  );
}

export default App;