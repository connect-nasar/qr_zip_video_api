import React, { useState, useEffect } from 'react';
import { Save, Eye, ArrowLeft, AlertCircle, CheckCircle, Target } from 'lucide-react';
import { useBlog } from '../../contexts/BlogContext';
import { calculateReadingTime, generateExcerpt, slugify } from '../../utils/blog';

interface PostEditorProps {
  postId?: string;
  onBack: () => void;
}

const PostEditor: React.FC<PostEditorProps> = ({ postId, onBack }) => {
  const { getPost, categories, addPost, updatePost } = useBlog();
  const [isPreview, setIsPreview] = useState(false);
  const [isSaving, setIsSaving] = useState(false);
  
  const [formData, setFormData] = useState({
    title: '',
    content: '',
    author: 'Admin',
    category: '',
    tags: '',
    featured: false,
    status: 'draft' as 'draft' | 'published',
    // SEO fields
    metaTitle: '',
    metaDescription: '',
    metaKeywords: '',
    focusKeyword: '',
    ogTitle: '',
    ogDescription: '',
    canonicalUrl: ''
  });

  const [seoScore, setSeoScore] = useState(0);

  useEffect(() => {
    if (postId) {
      const post = getPost(postId);
      if (post) {
        setFormData({
          title: post.title,
          content: post.content,
          author: post.author,
          category: post.category,
          tags: post.tags.join(', '),
          featured: post.featured,
          status: post.status,
          metaTitle: post.metaTitle || '',
          metaDescription: post.metaDescription || '',
          metaKeywords: post.metaKeywords || '',
          focusKeyword: post.focusKeyword || '',
          ogTitle: post.ogTitle || '',
          ogDescription: post.ogDescription || '',
          canonicalUrl: post.canonicalUrl || ''
        });
      }
    }
  }, [postId, getPost]);

  // Calculate SEO score
  useEffect(() => {
    let score = 0;
    
    // Title checks
    if (formData.title.length >= 30 && formData.title.length <= 60) score += 15;
    if (formData.focusKeyword && formData.title.toLowerCase().includes(formData.focusKeyword.toLowerCase())) score += 10;
    
    // Meta description checks
    if (formData.metaDescription.length >= 120 && formData.metaDescription.length <= 160) score += 15;
    if (formData.focusKeyword && formData.metaDescription.toLowerCase().includes(formData.focusKeyword.toLowerCase())) score += 10;
    
    // Content checks
    if (formData.content.length >= 300) score += 15;
    if (formData.focusKeyword && formData.content.toLowerCase().includes(formData.focusKeyword.toLowerCase())) score += 10;
    
    // Other SEO factors
    if (formData.metaKeywords) score += 5;
    if (formData.tags) score += 5;
    if (formData.ogTitle) score += 5;
    if (formData.ogDescription) score += 5;
    if (formData.canonicalUrl) score += 5;
    
    setSeoScore(score);
  }, [formData]);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSaving(true);

    try {
      const tagsArray = formData.tags
        .split(',')
        .map(tag => tag.trim())
        .filter(tag => tag.length > 0);

      const postData = {
        title: formData.title,
        content: formData.content,
        excerpt: generateExcerpt(formData.content),
        author: formData.author,
        category: formData.category,
        tags: tagsArray,
        readingTime: calculateReadingTime(formData.content),
        featured: formData.featured,
        status: formData.status,
        metaTitle: formData.metaTitle || formData.title,
        metaDescription: formData.metaDescription || generateExcerpt(formData.content),
        metaKeywords: formData.metaKeywords,
        focusKeyword: formData.focusKeyword,
        ogTitle: formData.ogTitle || formData.title,
        ogDescription: formData.ogDescription || generateExcerpt(formData.content),
        canonicalUrl: formData.canonicalUrl,
        seoScore
      };

      if (postId) {
        updatePost(postId, postData);
      } else {
        addPost(postData);
      }

      onBack();
    } catch (error) {
      console.error('Error saving post:', error);
    } finally {
      setIsSaving(false);
    }
  };

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) => {
    const { name, value, type } = e.target;
    setFormData(prev => ({
      ...prev,
      [name]: type === 'checkbox' ? (e.target as HTMLInputElement).checked : value
    }));
  };

  const getSeoScoreColor = (score: number) => {
    if (score >= 80) return 'text-green-600';
    if (score >= 60) return 'text-yellow-600';
    return 'text-red-600';
  };

  const getSeoScoreIcon = (score: number) => {
    if (score >= 80) return <CheckCircle className="w-5 h-5 text-green-600" />;
    if (score >= 60) return <AlertCircle className="w-5 h-5 text-yellow-600" />;
    return <AlertCircle className="w-5 h-5 text-red-600" />;
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <button
          onClick={onBack}
          className="flex items-center space-x-2 text-blue-600 hover:text-blue-700 transition-colors"
        >
          <ArrowLeft className="w-5 h-5" />
          <span>Back to posts</span>
        </button>

        <div className="flex items-center space-x-4">
          <div className="flex items-center space-x-2">
            {getSeoScoreIcon(seoScore)}
            <span className={`font-medium ${getSeoScoreColor(seoScore)}`}>
              SEO Score: {seoScore}%
            </span>
          </div>
          
          <button
            type="button"
            onClick={() => setIsPreview(!isPreview)}
            className={`flex items-center space-x-2 px-4 py-2 rounded-lg transition-colors ${
              isPreview
                ? 'bg-gray-100 text-gray-700'
                : 'bg-blue-100 text-blue-700'
            }`}
          >
            <Eye className="w-4 h-4" />
            <span>{isPreview ? 'Edit' : 'Preview'}</span>
          </button>
          
          <button
            onClick={handleSubmit}
            disabled={isSaving}
            className="flex items-center space-x-2 px-6 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 disabled:opacity-50 transition-colors"
          >
            <Save className="w-4 h-4" />
            <span>{isSaving ? 'Saving...' : 'Save'}</span>
          </button>
        </div>
      </div>

      <form onSubmit={handleSubmit} className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        {/* Main Content */}
        <div className="lg:col-span-2 space-y-6">
          <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
            <h2 className="text-xl font-semibold text-gray-900 mb-6">Content</h2>
            
            <div className="space-y-6">
              <div>
                <label htmlFor="title" className="block text-sm font-medium text-gray-700 mb-2">
                  Title *
                </label>
                <input
                  type="text"
                  id="title"
                  name="title"
                  value={formData.title}
                  onChange={handleChange}
                  required
                  className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent text-lg"
                  placeholder="Enter post title..."
                />
                <p className="mt-1 text-sm text-gray-500">
                  {formData.title.length} characters (recommended: 30-60)
                </p>
              </div>

              <div>
                <label htmlFor="content" className="block text-sm font-medium text-gray-700 mb-2">
                  Content *
                </label>
                <textarea
                  id="content"
                  name="content"
                  value={formData.content}
                  onChange={handleChange}
                  required
                  rows={20}
                  className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent font-mono text-sm"
                  placeholder="Write your post content here... (Supports Markdown)"
                />
                <p className="mt-2 text-sm text-gray-500">
                  {formData.content.split(' ').filter(w => w.length > 0).length} words • {calculateReadingTime(formData.content)} min read
                </p>
              </div>
            </div>
          </div>
        </div>

        {/* Sidebar */}
        <div className="space-y-6">
          {/* Post Settings */}
          <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
            <h3 className="text-lg font-semibold text-gray-900 mb-4">Post Settings</h3>
            
            <div className="space-y-4">
              <div>
                <label htmlFor="author" className="block text-sm font-medium text-gray-700 mb-2">
                  Author
                </label>
                <input
                  type="text"
                  id="author"
                  name="author"
                  value={formData.author}
                  onChange={handleChange}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                />
              </div>

              <div>
                <label htmlFor="category" className="block text-sm font-medium text-gray-700 mb-2">
                  Category *
                </label>
                <select
                  id="category"
                  name="category"
                  value={formData.category}
                  onChange={handleChange}
                  required
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                >
                  <option value="">Select category...</option>
                  {categories.map(category => (
                    <option key={category.id} value={category.name}>
                      {category.name}
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label htmlFor="tags" className="block text-sm font-medium text-gray-700 mb-2">
                  Tags
                </label>
                <input
                  type="text"
                  id="tags"
                  name="tags"
                  value={formData.tags}
                  onChange={handleChange}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                  placeholder="tag1, tag2, tag3..."
                />
              </div>

              <div>
                <label htmlFor="status" className="block text-sm font-medium text-gray-700 mb-2">
                  Status
                </label>
                <select
                  id="status"
                  name="status"
                  value={formData.status}
                  onChange={handleChange}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                >
                  <option value="draft">Draft</option>
                  <option value="published">Published</option>
                </select>
              </div>

              <div className="flex items-center">
                <input
                  type="checkbox"
                  id="featured"
                  name="featured"
                  checked={formData.featured}
                  onChange={handleChange}
                  className="h-4 w-4 text-blue-600 focus:ring-blue-500 border-gray-300 rounded"
                />
                <label htmlFor="featured" className="ml-2 block text-sm text-gray-700">
                  Featured post
                </label>
              </div>
            </div>
          </div>

          {/* SEO Settings */}
          <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
            <div className="flex items-center space-x-2 mb-4">
              <Target className="w-5 h-5 text-blue-600" />
              <h3 className="text-lg font-semibold text-gray-900">SEO Optimization</h3>
            </div>
            
            <div className="space-y-4">
              <div>
                <label htmlFor="focusKeyword" className="block text-sm font-medium text-gray-700 mb-2">
                  Focus Keyword
                </label>
                <input
                  type="text"
                  id="focusKeyword"
                  name="focusKeyword"
                  value={formData.focusKeyword}
                  onChange={handleChange}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                  placeholder="Main keyword for this post"
                />
              </div>

              <div>
                <label htmlFor="metaTitle" className="block text-sm font-medium text-gray-700 mb-2">
                  Meta Title
                </label>
                <input
                  type="text"
                  id="metaTitle"
                  name="metaTitle"
                  value={formData.metaTitle}
                  onChange={handleChange}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                  placeholder="SEO title (leave empty to use post title)"
                />
                <p className="mt-1 text-sm text-gray-500">
                  {formData.metaTitle.length} characters (recommended: 30-60)
                </p>
              </div>

              <div>
                <label htmlFor="metaDescription" className="block text-sm font-medium text-gray-700 mb-2">
                  Meta Description
                </label>
                <textarea
                  id="metaDescription"
                  name="metaDescription"
                  value={formData.metaDescription}
                  onChange={handleChange}
                  rows={3}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                  placeholder="SEO description (leave empty to auto-generate)"
                />
                <p className="mt-1 text-sm text-gray-500">
                  {formData.metaDescription.length} characters (recommended: 120-160)
                </p>
              </div>

              <div>
                <label htmlFor="metaKeywords" className="block text-sm font-medium text-gray-700 mb-2">
                  Meta Keywords
                </label>
                <input
                  type="text"
                  id="metaKeywords"
                  name="metaKeywords"
                  value={formData.metaKeywords}
                  onChange={handleChange}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                  placeholder="keyword1, keyword2, keyword3"
                />
              </div>

              <div>
                <label htmlFor="canonicalUrl" className="block text-sm font-medium text-gray-700 mb-2">
                  Canonical URL
                </label>
                <input
                  type="url"
                  id="canonicalUrl"
                  name="canonicalUrl"
                  value={formData.canonicalUrl}
                  onChange={handleChange}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                  placeholder="https://example.com/post-url"
                />
              </div>
            </div>
          </div>

          {/* SEO Score */}
          <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
            <div className="flex items-center justify-between mb-4">
              <h4 className="text-lg font-semibold text-gray-900">SEO Analysis</h4>
              <div className="flex items-center space-x-2">
                {getSeoScoreIcon(seoScore)}
                <span className={`text-lg font-bold ${getSeoScoreColor(seoScore)}`}>
                  {seoScore}%
                </span>
              </div>
            </div>
            
            <div className="space-y-3 text-sm">
              <div className="flex items-center justify-between">
                <span>Title length (30-60 chars)</span>
                <span className={formData.title.length >= 30 && formData.title.length <= 60 ? 'text-green-600' : 'text-red-600'}>
                  {formData.title.length >= 30 && formData.title.length <= 60 ? '✓' : '✗'}
                </span>
              </div>
              <div className="flex items-center justify-between">
                <span>Focus keyword in title</span>
                <span className={formData.focusKeyword && formData.title.toLowerCase().includes(formData.focusKeyword.toLowerCase()) ? 'text-green-600' : 'text-red-600'}>
                  {formData.focusKeyword && formData.title.toLowerCase().includes(formData.focusKeyword.toLowerCase()) ? '✓' : '✗'}
                </span>
              </div>
              <div className="flex items-center justify-between">
                <span>Meta description length</span>
                <span className={formData.metaDescription.length >= 120 && formData.metaDescription.length <= 160 ? 'text-green-600' : 'text-red-600'}>
                  {formData.metaDescription.length >= 120 && formData.metaDescription.length <= 160 ? '✓' : '✗'}
                </span>
              </div>
              <div className="flex items-center justify-between">
                <span>Content length (300+ words)</span>
                <span className={formData.content.split(' ').filter(w => w.length > 0).length >= 300 ? 'text-green-600' : 'text-red-600'}>
                  {formData.content.split(' ').filter(w => w.length > 0).length >= 300 ? '✓' : '✗'}
                </span>
              </div>
            </div>
          </div>
        </div>
      </form>
    </div>
  );
};

export default PostEditor;