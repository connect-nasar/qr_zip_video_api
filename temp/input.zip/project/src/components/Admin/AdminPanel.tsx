import React, { useState } from 'react';
import AdminHeader from './AdminHeader';
import Dashboard from './Dashboard';
import PostsManager from './PostsManager';
import PostEditor from './PostEditor';
import CommentsManager from './CommentsManager';
import SiteSettings from './SiteSettings';
import { useBlog } from '../../contexts/BlogContext';

interface AdminPanelProps {
  onNavigate: (path: string) => void;
}

type AdminView = 'dashboard' | 'posts' | 'write' | 'edit' | 'comments' | 'settings';

const AdminPanel: React.FC<AdminPanelProps> = ({ onNavigate }) => {
  const [currentView, setCurrentView] = useState<AdminView>('dashboard');
  const [selectedPostId, setSelectedPostId] = useState<string | null>(null);
  const { logout } = useBlog();

  const handleEditPost = (postId: string) => {
    setSelectedPostId(postId);
    setCurrentView('edit');
  };

  const handleCreatePost = () => {
    setSelectedPostId(null);
    setCurrentView('write');
  };

  const handleBackToPosts = () => {
    setCurrentView('posts');
    setSelectedPostId(null);
  };

  const handleLogout = () => {
    logout();
    onNavigate('/admin');
  };

  const renderContent = () => {
    switch (currentView) {
      case 'dashboard':
        return <Dashboard onNavigate={onNavigate} />;
      
      case 'posts':
        return (
          <PostsManager
            onEditPost={handleEditPost}
            onCreatePost={handleCreatePost}
          />
        );
      
      case 'write':
      case 'edit':
        return (
          <PostEditor
            postId={selectedPostId || undefined}
            onBack={handleBackToPosts}
          />
        );
      
      case 'comments':
        return <CommentsManager />;
      
      case 'settings':
        return <SiteSettings />;
      
      default:
        return <Dashboard onNavigate={onNavigate} />;
    }
  };

  return (
    <div className="min-h-screen bg-gray-50">
      <AdminHeader
        currentView={currentView}
        onViewChange={setCurrentView}
        onLogout={handleLogout}
        onNavigate={onNavigate}
      />
      
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {renderContent()}
      </main>
    </div>
  );
};

export default AdminPanel;