import React, { useState, useEffect } from 'react';
import PublicSite from '../Public/PublicSite';
import AdminPanel from '../Admin/AdminPanel';
import LoginPage from '../Admin/LoginPage';
import { useBlog } from '../../contexts/BlogContext';

const Router: React.FC = () => {
  const [currentPath, setCurrentPath] = useState(window.location.pathname);
  const { isAuthenticated } = useBlog();

  useEffect(() => {
    const handlePopState = () => {
      setCurrentPath(window.location.pathname);
    };

    window.addEventListener('popstate', handlePopState);
    return () => window.removeEventListener('popstate', handlePopState);
  }, []);

  const navigate = (path: string) => {
    window.history.pushState({}, '', path);
    setCurrentPath(path);
  };

  // Admin routes
  if (currentPath.startsWith('/admin')) {
    if (!isAuthenticated) {
      return <LoginPage onNavigate={navigate} />;
    }
    return <AdminPanel onNavigate={navigate} />;
  }

  // Public routes
  return <PublicSite onNavigate={navigate} currentPath={currentPath} />;
};

export default Router;