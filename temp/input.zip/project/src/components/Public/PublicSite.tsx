import React from 'react';
import PublicHeader from './PublicHeader';
import HomePage from './HomePage';
import PostPage from './PostPage';
import CategoryPage from './CategoryPage';
import { useBlog } from '../../contexts/BlogContext';

interface PublicSiteProps {
  onNavigate: (path: string) => void;
  currentPath: string;
}

const PublicSite: React.FC<PublicSiteProps> = ({ onNavigate, currentPath }) => {
  const { siteSettings } = useBlog();

  const renderContent = () => {
    if (currentPath === '/') {
      return <HomePage onNavigate={onNavigate} />;
    }
    
    if (currentPath.startsWith('/post/')) {
      const slug = currentPath.replace('/post/', '');
      return <PostPage slug={slug} onNavigate={onNavigate} />;
    }
    
    if (currentPath.startsWith('/category/')) {
      const categorySlug = currentPath.replace('/category/', '');
      return <CategoryPage categorySlug={categorySlug} onNavigate={onNavigate} />;
    }
    
    // 404 page
    return (
      <div className="min-h-screen flex items-center justify-center bg-gray-50">
        <div className="text-center">
          <h1 className="text-6xl font-bold text-gray-900 mb-4">404</h1>
          <p className="text-xl text-gray-600 mb-8">Page not found</p>
          <button
            onClick={() => onNavigate('/')}
            className="px-6 py-3 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors"
          >
            Go Home
          </button>
        </div>
      </div>
    );
  };

  return (
    <div className="min-h-screen bg-gray-50">
      {/* SEO Meta Tags */}
      <head>
        <title>{siteSettings.defaultMetaTitle}</title>
        <meta name="description" content={siteSettings.defaultMetaDescription} />
        <meta property="og:title" content={siteSettings.defaultMetaTitle} />
        <meta property="og:description" content={siteSettings.defaultMetaDescription} />
        <meta property="og:type" content="website" />
        <meta property="og:url" content={siteSettings.siteUrl} />
        <meta name="twitter:card" content="summary_large_image" />
        <meta name="twitter:title" content={siteSettings.defaultMetaTitle} />
        <meta name="twitter:description" content={siteSettings.defaultMetaDescription} />
        {siteSettings.googleAnalyticsId && (
          <script async src={`https://www.googletagmanager.com/gtag/js?id=${siteSettings.googleAnalyticsId}`}></script>
        )}
      </head>
      
      <PublicHeader onNavigate={onNavigate} />
      <main>
        {renderContent()}
      </main>
      
      {/* Footer */}
      <footer className="bg-gray-900 text-white py-12">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
            <div className="col-span-1 md:col-span-2">
              <h3 className="text-2xl font-bold mb-4">{siteSettings.siteName}</h3>
              <p className="text-gray-300 mb-4">{siteSettings.siteDescription}</p>
              <div className="flex space-x-4">
                {siteSettings.socialMedia.twitter && (
                  <a href={`https://twitter.com/${siteSettings.socialMedia.twitter}`} className="text-gray-300 hover:text-white">
                    Twitter
                  </a>
                )}
                {siteSettings.socialMedia.facebook && (
                  <a href={`https://facebook.com/${siteSettings.socialMedia.facebook}`} className="text-gray-300 hover:text-white">
                    Facebook
                  </a>
                )}
                {siteSettings.socialMedia.linkedin && (
                  <a href={`https://linkedin.com/${siteSettings.socialMedia.linkedin}`} className="text-gray-300 hover:text-white">
                    LinkedIn
                  </a>
                )}
              </div>
            </div>
            <div>
              <h4 className="text-lg font-semibold mb-4">Quick Links</h4>
              <ul className="space-y-2">
                <li><button onClick={() => onNavigate('/')} className="text-gray-300 hover:text-white">Home</button></li>
                <li><button onClick={() => onNavigate('/category/web-development')} className="text-gray-300 hover:text-white">Web Development</button></li>
                <li><button onClick={() => onNavigate('/category/programming')} className="text-gray-300 hover:text-white">Programming</button></li>
                <li><button onClick={() => onNavigate('/category/blogging')} className="text-gray-300 hover:text-white">Blogging</button></li>
              </ul>
            </div>
            <div>
              <h4 className="text-lg font-semibold mb-4">About</h4>
              <ul className="space-y-2">
                <li><span className="text-gray-300">Contact Us</span></li>
                <li><span className="text-gray-300">Privacy Policy</span></li>
                <li><span className="text-gray-300">Terms of Service</span></li>
              </ul>
            </div>
          </div>
          <div className="border-t border-gray-800 mt-8 pt-8 text-center text-gray-300">
            <p>&copy; 2024 {siteSettings.siteName}. All rights reserved.</p>
          </div>
        </div>
      </footer>
    </div>
  );
};

export default PublicSite;