import React, { useState } from 'react';
import { ArrowLeft, Calendar, Clock, User, Tag, Share2, MessageCircle } from 'lucide-react';
import { useBlog } from '../../contexts/BlogContext';
import { formatDate } from '../../utils/blog';
import CommentSection from './CommentSection';

interface PostPageProps {
  slug: string;
  onNavigate: (path: string) => void;
}

const PostPage: React.FC<PostPageProps> = ({ slug, onNavigate }) => {
  const { getPostBySlug, siteSettings } = useBlog();
  const [showComments, setShowComments] = useState(false);
  const post = getPostBySlug(slug);

  if (!post || post.status !== 'published') {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-center">
          <h1 className="text-4xl font-bold text-gray-900 mb-4">Post Not Found</h1>
          <p className="text-gray-600 mb-8">The tutorial you're looking for doesn't exist or has been removed.</p>
          <button
            onClick={() => onNavigate('/')}
            className="px-6 py-3 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors"
          >
            Back to Home
          </button>
        </div>
      </div>
    );
  }

  const formatContent = (content: string) => {
    return content.split('\n').map((paragraph, index) => {
      if (paragraph.startsWith('# ')) {
        return (
          <h1 key={index} className="text-4xl font-bold text-gray-900 mb-8 mt-12 first:mt-0">
            {paragraph.replace('# ', '')}
          </h1>
        );
      }
      if (paragraph.startsWith('## ')) {
        return (
          <h2 key={index} className="text-3xl font-bold text-gray-900 mb-6 mt-10">
            {paragraph.replace('## ', '')}
          </h2>
        );
      }
      if (paragraph.startsWith('### ')) {
        return (
          <h3 key={index} className="text-2xl font-bold text-gray-900 mb-4 mt-8">
            {paragraph.replace('### ', '')}
          </h3>
        );
      }
      if (paragraph.startsWith('#### ')) {
        return (
          <h4 key={index} className="text-xl font-bold text-gray-900 mb-3 mt-6">
            {paragraph.replace('#### ', '')}
          </h4>
        );
      }
      if (paragraph.startsWith('- ')) {
        return (
          <li key={index} className="text-gray-700 mb-2 ml-6 list-disc">
            {paragraph.replace('- ', '')}
          </li>
        );
      }
      if (paragraph.startsWith('```')) {
        return (
          <pre key={index} className="bg-gray-900 text-gray-100 p-6 rounded-lg overflow-x-auto mb-6 text-sm">
            <code>
              {paragraph.replace(/```\w*\n?/, '').replace(/```$/, '')}
            </code>
          </pre>
        );
      }
      if (paragraph.includes('**')) {
        const boldText = paragraph.replace(/\*\*(.*?)\*\*/g, '<strong class="font-semibold">$1</strong>');
        return (
          <p key={index} className="text-gray-700 mb-6 leading-relaxed text-lg" dangerouslySetInnerHTML={{ __html: boldText }} />
        );
      }
      if (paragraph.includes('`')) {
        const codeText = paragraph.replace(/`(.*?)`/g, '<code class="bg-gray-100 px-2 py-1 rounded text-sm font-mono text-gray-800">$1</code>');
        return (
          <p key={index} className="text-gray-700 mb-6 leading-relaxed text-lg" dangerouslySetInnerHTML={{ __html: codeText }} />
        );
      }
      if (paragraph.trim() === '') {
        return <div key={index} className="mb-4" />;
      }
      return (
        <p key={index} className="text-gray-700 mb-6 leading-relaxed text-lg">
          {paragraph}
        </p>
      );
    });
  };

  const sharePost = () => {
    if (navigator.share) {
      navigator.share({
        title: post.title,
        text: post.excerpt,
        url: window.location.href,
      });
    } else {
      navigator.clipboard.writeText(window.location.href);
      alert('Link copied to clipboard!');
    }
  };

  return (
    <div className="min-h-screen bg-white">
      {/* SEO Meta Tags */}
      <head>
        <title>{post.metaTitle || post.title}</title>
        <meta name="description" content={post.metaDescription || post.excerpt} />
        <meta name="keywords" content={post.metaKeywords || post.tags.join(', ')} />
        <meta property="og:title" content={post.ogTitle || post.title} />
        <meta property="og:description" content={post.ogDescription || post.excerpt} />
        <meta property="og:type" content="article" />
        <meta property="og:url" content={`${siteSettings.siteUrl}/post/${post.slug}`} />
        {post.ogImage && <meta property="og:image" content={post.ogImage} />}
        <meta name="twitter:card" content="summary_large_image" />
        <meta name="twitter:title" content={post.title} />
        <meta name="twitter:description" content={post.excerpt} />
        {post.canonicalUrl && <link rel="canonical" href={post.canonicalUrl} />}
        <script type="application/ld+json">
          {JSON.stringify({
            "@context": "https://schema.org",
            "@type": "Article",
            "headline": post.title,
            "description": post.excerpt,
            "author": {
              "@type": "Person",
              "name": post.author
            },
            "datePublished": post.publishedAt.toISOString(),
            "dateModified": post.updatedAt.toISOString(),
            "publisher": {
              "@type": "Organization",
              "name": siteSettings.siteName,
              "url": siteSettings.siteUrl
            }
          })}
        </script>
      </head>

      <article className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Back Button */}
        <button
          onClick={() => onNavigate('/')}
          className="flex items-center space-x-2 text-blue-600 hover:text-blue-700 mb-8 transition-colors"
        >
          <ArrowLeft className="w-5 h-5" />
          <span>Back to tutorials</span>
        </button>

        {/* Article Header */}
        <header className="mb-12">
          <div className="flex items-center space-x-2 mb-6">
            <span className="bg-blue-100 text-blue-800 px-4 py-2 rounded-full text-sm font-medium">
              {post.category}
            </span>
            {post.featured && (
              <span className="bg-yellow-100 text-yellow-800 px-4 py-2 rounded-full text-sm font-medium">
                Featured
              </span>
            )}
          </div>

          <h1 className="text-4xl md:text-5xl font-bold text-gray-900 mb-6 leading-tight">
            {post.title}
          </h1>

          <div className="flex flex-wrap items-center gap-6 text-gray-600 mb-8">
            <div className="flex items-center space-x-2">
              <User className="w-5 h-5" />
              <span className="font-medium">{post.author}</span>
            </div>
            <div className="flex items-center space-x-2">
              <Calendar className="w-5 h-5" />
              <span>{formatDate(post.publishedAt)}</span>
            </div>
            <div className="flex items-center space-x-2">
              <Clock className="w-5 h-5" />
              <span>{post.readingTime} min read</span>
            </div>
            <button
              onClick={sharePost}
              className="flex items-center space-x-2 text-blue-600 hover:text-blue-700 transition-colors"
            >
              <Share2 className="w-5 h-5" />
              <span>Share</span>
            </button>
          </div>

          {/* Tags */}
          <div className="flex flex-wrap gap-2 mb-8">
            {post.tags.map((tag, index) => (
              <span
                key={index}
                className="inline-flex items-center px-3 py-1 bg-gray-100 text-gray-700 rounded-full text-sm"
              >
                <Tag className="w-3 h-3 mr-1" />
                {tag}
              </span>
            ))}
          </div>

          <div className="text-xl text-gray-600 leading-relaxed border-l-4 border-blue-500 pl-6 bg-blue-50 p-6 rounded-r-lg">
            {post.excerpt}
          </div>
        </header>

        {/* Article Content */}
        <div className="prose prose-lg max-w-none">
          {formatContent(post.content)}
        </div>

        {/* Article Footer */}
        <footer className="mt-16 pt-8 border-t border-gray-200">
          <div className="flex items-center justify-between mb-8">
            <div className="text-sm text-gray-500">
              Last updated: {formatDate(post.updatedAt)}
            </div>
            <button
              onClick={sharePost}
              className="flex items-center space-x-2 px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors"
            >
              <Share2 className="w-4 h-4" />
              <span>Share this tutorial</span>
            </button>
          </div>

          {/* Comments Toggle */}
          <div className="bg-gray-50 rounded-lg p-6">
            <button
              onClick={() => setShowComments(!showComments)}
              className="flex items-center space-x-2 text-lg font-semibold text-gray-900 hover:text-blue-600 transition-colors"
            >
              <MessageCircle className="w-5 h-5" />
              <span>Comments</span>
            </button>
            <p className="text-gray-600 mt-2">
              Share your thoughts and questions about this tutorial
            </p>
          </div>
        </footer>
      </article>

      {/* Comments Section */}
      {showComments && (
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 pb-16">
          <CommentSection postId={post.id} />
        </div>
      )}
    </div>
  );
};

export default PostPage;