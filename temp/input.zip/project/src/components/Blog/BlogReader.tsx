import React from 'react';
import { ArrowLeft, Calendar, Clock, Tag, User, Edit } from 'lucide-react';
import { BlogPost } from '../../types/blog';
import { formatDate } from '../../utils/blog';

interface BlogReaderProps {
  post: BlogPost;
  onBack: () => void;
  onEdit: (id: string) => void;
  canEdit?: boolean;
}

const BlogReader: React.FC<BlogReaderProps> = ({ 
  post, 
  onBack, 
  onEdit, 
  canEdit = false 
}) => {
  const formatContent = (content: string) => {
    return content.split('\n').map((paragraph, index) => {
      if (paragraph.startsWith('# ')) {
        return (
          <h1 key={index} className="text-3xl font-bold text-gray-900 mb-6 mt-8">
            {paragraph.replace('# ', '')}
          </h1>
        );
      }
      if (paragraph.startsWith('## ')) {
        return (
          <h2 key={index} className="text-2xl font-bold text-gray-900 mb-4 mt-6">
            {paragraph.replace('## ', '')}
          </h2>
        );
      }
      if (paragraph.startsWith('### ')) {
        return (
          <h3 key={index} className="text-xl font-bold text-gray-900 mb-3 mt-5">
            {paragraph.replace('### ', '')}
          </h3>
        );
      }
      if (paragraph.startsWith('- ')) {
        return (
          <li key={index} className="text-gray-700 mb-1 ml-4">
            {paragraph.replace('- ', '')}
          </li>
        );
      }
      if (paragraph.startsWith('```')) {
        return (
          <pre key={index} className="bg-gray-100 p-4 rounded-lg overflow-x-auto mb-4">
            <code className="text-sm font-mono text-gray-800">
              {paragraph.replace(/```\w*\n?/, '').replace(/```$/, '')}
            </code>
          </pre>
        );
      }
      if (paragraph.includes('**')) {
        const boldText = paragraph.replace(/\*\*(.*?)\*\*/g, '<strong>$1</strong>');
        return (
          <p key={index} className="text-gray-700 mb-4 leading-relaxed" dangerouslySetInnerHTML={{ __html: boldText }} />
        );
      }
      if (paragraph.includes('`')) {
        const codeText = paragraph.replace(/`(.*?)`/g, '<code class="bg-gray-100 px-2 py-1 rounded text-sm font-mono">$1</code>');
        return (
          <p key={index} className="text-gray-700 mb-4 leading-relaxed" dangerouslySetInnerHTML={{ __html: codeText }} />
        );
      }
      if (paragraph.trim() === '') {
        return <br key={index} />;
      }
      return (
        <p key={index} className="text-gray-700 mb-4 leading-relaxed">
          {paragraph}
        </p>
      );
    });
  };

  return (
    <div className="max-w-4xl mx-auto px-4 py-8">
      {/* Header */}
      <div className="mb-8">
        <button
          onClick={onBack}
          className="flex items-center space-x-2 text-blue-600 hover:text-blue-700 mb-6 transition-colors"
        >
          <ArrowLeft className="w-5 h-5" />
          <span>Back to posts</span>
        </button>

        <div className="flex items-center justify-between mb-6">
          <div className="flex items-center space-x-4">
            {post.status === 'draft' && (
              <span className="bg-yellow-100 text-yellow-800 px-3 py-1 rounded-full text-sm font-medium">
                Draft
              </span>
            )}
            {post.featured && (
              <span className="bg-blue-100 text-blue-800 px-3 py-1 rounded-full text-sm font-medium">
                Featured
              </span>
            )}
          </div>
          
          {canEdit && (
            <button
              onClick={() => onEdit(post.id)}
              className="flex items-center space-x-2 px-4 py-2 text-blue-600 hover:bg-blue-50 rounded-lg transition-colors"
            >
              <Edit className="w-4 h-4" />
              <span>Edit</span>
            </button>
          )}
        </div>

        <h1 className="text-4xl font-bold text-gray-900 mb-6 leading-tight">
          {post.title}
        </h1>

        <div className="flex flex-wrap items-center gap-6 text-sm text-gray-600 mb-8">
          <div className="flex items-center space-x-2">
            <User className="w-4 h-4" />
            <span>{post.author}</span>
          </div>
          <div className="flex items-center space-x-2">
            <Calendar className="w-4 h-4" />
            <span>{formatDate(post.publishedAt)}</span>
          </div>
          <div className="flex items-center space-x-2">
            <Clock className="w-4 h-4" />
            <span>{post.readingTime} min read</span>
          </div>
          <div className="flex items-center space-x-2">
            <Tag className="w-4 h-4" />
            <span>{post.category}</span>
          </div>
        </div>

        {/* Tags */}
        <div className="flex flex-wrap gap-2 mb-8">
          {post.tags.map((tag, index) => (
            <span
              key={index}
              className="inline-flex items-center px-3 py-1 bg-gray-100 text-gray-700 rounded-full text-sm"
            >
              <Tag className="w-3 h-3 mr-1" />
              {tag}
            </span>
          ))}
        </div>
      </div>

      {/* Content */}
      <div className="prose prose-lg max-w-none">
        <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-8">
          {formatContent(post.content)}
        </div>
      </div>

      {/* Footer */}
      <div className="mt-12 pt-8 border-t border-gray-200">
        <div className="flex items-center justify-between">
          <div className="text-sm text-gray-500">
            Last updated: {formatDate(post.updatedAt)}
          </div>
          <div className="flex items-center space-x-4">
            <span className="text-sm text-gray-500">Share this post</span>
            <div className="flex items-center space-x-2">
              <button className="text-blue-600 hover:text-blue-700 text-sm">
                Twitter
              </button>
              <button className="text-blue-600 hover:text-blue-700 text-sm">
                LinkedIn
              </button>
              <button className="text-blue-600 hover:text-blue-700 text-sm">
                Copy link
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default BlogReader;