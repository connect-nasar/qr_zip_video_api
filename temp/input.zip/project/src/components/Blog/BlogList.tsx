import React from 'react';
import { BookOpen, Filter } from 'lucide-react';
import { useBlog } from '../../contexts/BlogContext';
import BlogCard from './BlogCard';

interface BlogListProps {
  onViewPost: (id: string) => void;
  onEditPost: (id: string) => void;
  showActions?: boolean;
}

const BlogList: React.FC<BlogListProps> = ({ 
  onViewPost, 
  onEditPost, 
  showActions = false 
}) => {
  const { getFilteredPosts, deletePost, categories, filters } = useBlog();
  const posts = getFilteredPosts();
  const featuredPosts = posts.filter(post => post.featured && post.status === 'published');
  const regularPosts = posts.filter(post => !post.featured || post.status !== 'published');

  if (posts.length === 0) {
    return (
      <div className="text-center py-12">
        <BookOpen className="w-16 h-16 text-gray-300 mx-auto mb-4" />
        <h3 className="text-lg font-medium text-gray-900 mb-2">No posts found</h3>
        <p className="text-gray-600 mb-6">
          {filters.searchQuery || filters.category || filters.status !== 'all'
            ? 'Try adjusting your search filters'
            : 'Start by creating your first blog post'}
        </p>
      </div>
    );
  }

  return (
    <div className="space-y-8">
      {/* Featured Posts */}
      {featuredPosts.length > 0 && (
        <section>
          <div className="flex items-center justify-between mb-6">
            <h2 className="text-2xl font-bold text-gray-900">Featured Posts</h2>
            <div className="flex items-center space-x-2 text-sm text-gray-500">
              <Filter className="w-4 h-4" />
              <span>{featuredPosts.length} featured</span>
            </div>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {featuredPosts.map(post => (
              <BlogCard
                key={post.id}
                post={post}
                onView={onViewPost}
                onEdit={onEditPost}
                onDelete={deletePost}
                showActions={showActions}
              />
            ))}
          </div>
        </section>
      )}

      {/* Regular Posts */}
      {regularPosts.length > 0 && (
        <section>
          <div className="flex items-center justify-between mb-6">
            <h2 className="text-2xl font-bold text-gray-900">
              {featuredPosts.length > 0 ? 'All Posts' : 'Latest Posts'}
            </h2>
            <div className="flex items-center space-x-2 text-sm text-gray-500">
              <Filter className="w-4 h-4" />
              <span>{regularPosts.length} posts</span>
            </div>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {regularPosts.map(post => (
              <BlogCard
                key={post.id}
                post={post}
                onView={onViewPost}
                onEdit={onEditPost}
                onDelete={deletePost}
                showActions={showActions}
              />
            ))}
          </div>
        </section>
      )}

      {/* Categories Summary */}
      {categories.length > 0 && (
        <section className="bg-gray-50 rounded-xl p-6">
          <h3 className="text-lg font-semibold text-gray-900 mb-4">Categories</h3>
          <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-5 gap-4">
            {categories.map(category => (
              <div
                key={category.id}
                className="text-center p-3 bg-white rounded-lg border border-gray-200 hover:shadow-sm transition-shadow"
              >
                <div className="text-2xl font-bold text-blue-600 mb-1">
                  {category.postCount}
                </div>
                <div className="text-sm font-medium text-gray-900">
                  {category.name}
                </div>
                <div className="text-xs text-gray-500">
                  {category.description}
                </div>
              </div>
            ))}
          </div>
        </section>
      )}
    </div>
  );
};

export default BlogList;