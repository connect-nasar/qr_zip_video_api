import React from 'react';
import { PlusCircle, TrendingUp, BookOpen, Users } from 'lucide-react';
import { useBlog } from '../../contexts/BlogContext';
import BlogList from '../Blog/BlogList';

interface HomePageProps {
  onViewPost: (id: string) => void;
  onCreatePost: () => void;
}

const HomePage: React.FC<HomePageProps> = ({ onViewPost, onCreatePost }) => {
  const { posts, categories } = useBlog();
  
  const publishedPosts = posts.filter(post => post.status === 'published');
  const draftPosts = posts.filter(post => post.status === 'draft');
  const totalReadingTime = posts.reduce((total, post) => total + post.readingTime, 0);
  const totalCategories = categories.length;

  return (
    <div className="max-w-7xl mx-auto px-4 py-8">
      {/* Hero Section */}
      <div className="text-center mb-12">
        <h1 className="text-4xl font-bold text-gray-900 mb-4">
          Welcome to BlogCraft
        </h1>
        <p className="text-xl text-gray-600 mb-8 max-w-2xl mx-auto">
          Discover insightful articles, tutorials, and thoughts on web development, design, and technology.
        </p>
        
        <button
          onClick={onCreatePost}
          className="inline-flex items-center px-6 py-3 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors font-medium"
        >
          <PlusCircle className="w-5 h-5 mr-2" />
          Create New Post
        </button>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-12">
        <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
          <div className="flex items-center">
            <div className="p-3 bg-blue-100 rounded-lg">
              <BookOpen className="w-6 h-6 text-blue-600" />
            </div>
            <div className="ml-4">
              <p className="text-sm font-medium text-gray-600">Published Posts</p>
              <p className="text-2xl font-bold text-gray-900">{publishedPosts.length}</p>
            </div>
          </div>
        </div>

        <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
          <div className="flex items-center">
            <div className="p-3 bg-yellow-100 rounded-lg">
              <TrendingUp className="w-6 h-6 text-yellow-600" />
            </div>
            <div className="ml-4">
              <p className="text-sm font-medium text-gray-600">Draft Posts</p>
              <p className="text-2xl font-bold text-gray-900">{draftPosts.length}</p>
            </div>
          </div>
        </div>

        <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
          <div className="flex items-center">
            <div className="p-3 bg-green-100 rounded-lg">
              <Users className="w-6 h-6 text-green-600" />
            </div>
            <div className="ml-4">
              <p className="text-sm font-medium text-gray-600">Categories</p>
              <p className="text-2xl font-bold text-gray-900">{totalCategories}</p>
            </div>
          </div>
        </div>

        <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
          <div className="flex items-center">
            <div className="p-3 bg-purple-100 rounded-lg">
              <BookOpen className="w-6 h-6 text-purple-600" />
            </div>
            <div className="ml-4">
              <p className="text-sm font-medium text-gray-600">Total Reading Time</p>
              <p className="text-2xl font-bold text-gray-900">{totalReadingTime}m</p>
            </div>
          </div>
        </div>
      </div>

      {/* Blog List */}
      <BlogList 
        onViewPost={onViewPost} 
        onEditPost={() => {}} 
        showActions={false}
      />
    </div>
  );
};

export default HomePage;